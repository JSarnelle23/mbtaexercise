#!/usr/bin/python3
 from .cli import run

run()