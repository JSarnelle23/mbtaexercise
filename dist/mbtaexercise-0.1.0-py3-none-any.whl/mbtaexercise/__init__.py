__version__ = "0.1.0"
__projectname__ = "mbtaExercise"

from .cli import run

__all__ = ["run"]